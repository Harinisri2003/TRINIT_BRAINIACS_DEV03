package com.dhanusrisapplication.app.modules.iphone14one.`data`.model

import com.dhanusrisapplication.app.R
import com.dhanusrisapplication.app.appcomponents.di.MyApp
import kotlin.String

data class Iphone14OneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCOMMUNITYFORUM: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_community_forum)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPostyourdoubt: String? =
      MyApp.getInstance().resources.getString(R.string.msg_post_your_doubt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDhanusritk: String? = MyApp.getInstance().resources.getString(R.string.lbl_dhanusri_tk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWeekday: String? = MyApp.getInstance().resources.getString(R.string.msg_posted_wednesda)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIamgrowingDr: String? =
      MyApp.getInstance().resources.getString(R.string.msg_i_am_growing_dr)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReply: String? = MyApp.getInstance().resources.getString(R.string.lbl_reply)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeReplies: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_replies)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGowrishubak: String? = MyApp.getInstance().resources.getString(R.string.lbl_gowrishuba_k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWeekdayOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_posted_monday)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMyaloeverais: String? =
      MyApp.getInstance().resources.getString(R.string.msg_my_aloe_vera_is)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReplyOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_reply)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeRepliesOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_replies)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDharshualagar: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dharshu_alagar)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWeekdayTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_posted_monday)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtogrowcac: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_grow_cac)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReplyTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_reply)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeRepliesTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_replies)

)
